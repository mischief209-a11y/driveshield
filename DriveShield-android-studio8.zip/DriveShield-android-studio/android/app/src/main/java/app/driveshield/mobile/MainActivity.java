package app.driveshield.mobile;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.content.FileProvider;
import com.getcapacitor.BridgeActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Set;

public class MainActivity extends BridgeActivity {
  private static MainActivity current;
  private WebView printWeb;

  private final BroadcastReceiver carReceiver =
      new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
          String action = intent.getAction();
          BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
          String id = "";
          String name = "";
          if (device != null) {
            try {
              id = device.getAddress() != null ? device.getAddress() : "";
              name = device.getName() != null ? device.getName() : "";
            } catch (SecurityException ignored) {
            }
          }
          if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
            fireCarEvent(id, name, "connected");
          } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
            fireCarEvent(id, name, "disconnected");
          }
        }
      };

  static void pushGps(double lat, double lng, float acc) {
    MainActivity act = current;
    if (act == null) return;
    act.runOnUiThread(
        () -> {
          WebView view = act.getBridge() != null ? act.getBridge().getWebView() : null;
          if (view == null) return;
          view.evaluateJavascript(
              "window.dispatchEvent(new CustomEvent('driveshield-gps',{detail:{lat:"
                  + lat
                  + ",lng:"
                  + lng
                  + ",acc:"
                  + acc
                  + "}}))",
              null);
        });
  }

  static void requestCancelTrip() {
    MainActivity act = current;
    try {
      Context ctx = act != null ? act : null;
      if (ctx != null) {
        ctx.getSharedPreferences("driveshield", MODE_PRIVATE)
            .edit()
            .putBoolean("cancelTrip", true)
            .apply();
      }
    } catch (Exception ignored) {
    }
    if (act != null) {
      act.runOnUiThread(
          () -> {
            WebView view = act.getBridge() != null ? act.getBridge().getWebView() : null;
            if (view == null) return;
            view.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('driveshield-trip-cancel'))", null);
          });
    }
  }

  void fireCarEvent(String id, String name, String kind) {
    final String event =
        "disconnected".equals(kind) ? "driveshield-car-disconnected" : "driveshield-car-connected";
    runOnUiThread(
        () -> {
          WebView view = getBridge() != null ? getBridge().getWebView() : null;
          if (view == null) return;
          view.evaluateJavascript(
              "window.dispatchEvent(new CustomEvent('"
                  + event
                  + "',{detail:{id:'"
                  + jsonEscape(id)
                  + "',name:'"
                  + jsonEscape(name)
                  + "'}}))",
              null);
        });
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    current = this;
    IntentFilter filter = new IntentFilter();
    filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
    filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);
    if (Build.VERSION.SDK_INT >= 33) {
      registerReceiver(carReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    } else {
      registerReceiver(carReceiver, filter);
    }
    handleAuto(getIntent());
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleAuto(intent);
  }

  @Override
  public void onStart() {
    super.onStart();
    current = this;
    WebView view = getBridge() != null ? getBridge().getWebView() : null;
    if (view != null) {
      view.addJavascriptInterface(new DriveShieldNative(), "DriveShieldNative");
    }
    try {
      SharedPreferences prefs = getSharedPreferences("driveshield", MODE_PRIVATE);
      if (prefs.getBoolean("cancelTrip", false) && view != null) {
        prefs.edit().putBoolean("cancelTrip", false).apply();
        view.postDelayed(
            () ->
                view.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('driveshield-trip-cancel'))", null),
            400);
      }
    } catch (Exception ignored) {
    }
  }

  @Override
  public void onPause() {
    super.onPause();
    // Keep the WebView executing so live miles still land in the log with the screen off.
    try {
      WebView view = getBridge() != null ? getBridge().getWebView() : null;
      if (view != null) view.onResume();
    } catch (Exception ignored) {
    }
  }

  @Override
  public void onDestroy() {
    if (current == this) current = null;
    try {
      unregisterReceiver(carReceiver);
    } catch (Exception ignored) {
    }
    super.onDestroy();
  }

  private void handleAuto(Intent intent) {
    if (intent == null) return;
    final String id = intent.getStringExtra("carId");
    final String name = intent.getStringExtra("carName");
    if (intent.getBooleanExtra("autoStop", false)) {
      getWindow()
          .getDecorView()
          .postDelayed(
              () -> fireCarEvent(id != null ? id : "", name != null ? name : "", "disconnected"),
              800);
      return;
    }
    if (!intent.getBooleanExtra("autoStart", false)) return;
    getWindow()
        .getDecorView()
        .postDelayed(
            () -> fireCarEvent(id != null ? id : "", name != null ? name : "", "connected"),
            800);
  }

  public class DriveShieldNative {
    @JavascriptInterface
    public String listBondedBluetooth() {
      JSONArray out = new JSONArray();
      try {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) return "[]";
        @SuppressLint("MissingPermission")
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded == null) return "[]";
        for (BluetoothDevice device : bonded) {
          JSONObject row = new JSONObject();
          row.put("id", device.getAddress() != null ? device.getAddress() : "");
          row.put("name", device.getName() != null ? device.getName() : "Bluetooth device");
          out.put(row);
        }
      } catch (Exception ignored) {
      }
      return out.toString();
    }

    @JavascriptInterface
    public void saveCarStereo(String id, String name, boolean autoStart) {
      getSharedPreferences("driveshield", MODE_PRIVATE)
          .edit()
          .putString("stereoId", id != null ? id : "")
          .putString("stereoName", name != null ? name : "")
          .putBoolean("autoStart", autoStart)
          .apply();
    }

    @JavascriptInterface
    public void startTripTrack() {
      TripTrackService.start(MainActivity.this);
    }

    @JavascriptInterface
    public void stopTripTrack() {
      TripTrackService.stop(MainActivity.this);
    }

    @JavascriptInterface
    public void updateTripMiles(String text) {
      TripTrackService.miles(MainActivity.this, text);
    }

    @JavascriptInterface
    public String getTrackTrail() {
      return TripTrackService.trailJson();
    }

    @JavascriptInterface
    public double getTrackMiles() {
      return TripTrackService.trailMiles();
    }

    @JavascriptInterface
    public void requestTrackingPermissions() {
      java.util.ArrayList<String> need = new java.util.ArrayList<>();
      addIfMissing(need, Manifest.permission.ACCESS_FINE_LOCATION);
      addIfMissing(need, Manifest.permission.ACCESS_COARSE_LOCATION);
      if (Build.VERSION.SDK_INT >= 31) {
        addIfMissing(need, Manifest.permission.BLUETOOTH_CONNECT);
        addIfMissing(need, Manifest.permission.BLUETOOTH_SCAN);
      }
      if (Build.VERSION.SDK_INT >= 33) addIfMissing(need, Manifest.permission.POST_NOTIFICATIONS);
      if (!need.isEmpty()) {
        ActivityCompat.requestPermissions(MainActivity.this, need.toArray(new String[0]), 71);
      } else {
        askUnrestrictedBattery();
        firePermissionReady();
      }
    }

    @JavascriptInterface
    public void requestUnrestrictedBattery() {
      askUnrestrictedBattery();
    }

    @JavascriptInterface
    public boolean printHtml(String html, String jobName) {
      final String body = html == null ? "" : html;
      final String job = jobName == null || jobName.isEmpty() ? "DriveShield ledger" : jobName;
      runOnUiThread(
          () -> {
            try {
              printWeb = new WebView(MainActivity.this);
              printWeb.setWebViewClient(
                  new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                      try {
                        PrintManager pm =
                            (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm == null) return;
                        PrintDocumentAdapter adapter =
                            Build.VERSION.SDK_INT >= 21
                                ? view.createPrintDocumentAdapter(job)
                                : view.createPrintDocumentAdapter();
                        pm.print(job, adapter, new PrintAttributes.Builder().build());
                      } catch (Exception ignored) {
                      }
                    }
                  });
              printWeb.loadDataWithBaseURL(
                  "https://localhost/", body, "text/html", "UTF-8", null);
            } catch (Exception ignored) {
            }
          });
      return true;
    }

    private void askUnrestrictedBattery() {
      if (Build.VERSION.SDK_INT < 23) return;
      try {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName())) return;
        Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivity(intent);
      } catch (Exception ignored) {
      }
    }

    private void addIfMissing(java.util.ArrayList<String> need, String permission) {
      if (ContextCompat.checkSelfPermission(MainActivity.this, permission)
          != PackageManager.PERMISSION_GRANTED) {
        need.add(permission);
      }
    }
  }

  @Override
  public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == 71 || requestCode == 72) {
      firePermissionReady();
      if (requestCode == 71) {
        try {
          new DriveShieldNative().askUnrestrictedBattery();
        } catch (Exception ignored) {
        }
      }
    }
  }

  static void firePermissionReady() {
    MainActivity act = current;
    if (act == null) return;
    act.runOnUiThread(
        () -> {
          WebView view = act.getBridge() != null ? act.getBridge().getWebView() : null;
          if (view == null) return;
          view.evaluateJavascript(
              "window.dispatchEvent(new CustomEvent('driveshield-permissions'))", null);
        });
  }

  private static String jsonEscape(String raw) {
    if (raw == null) return "";
    return raw.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
  }
}
