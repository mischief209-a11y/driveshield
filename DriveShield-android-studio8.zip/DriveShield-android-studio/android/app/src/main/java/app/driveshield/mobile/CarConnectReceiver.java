package app.driveshield.mobile;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class CarConnectReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    String action = intent.getAction();
    boolean connected = BluetoothDevice.ACTION_ACL_CONNECTED.equals(action);
    boolean disconnected = BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action);
    if (!connected && !disconnected) return;
    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
    String id = "";
    String name = "";
    if (device != null) {
      try {
        id = device.getAddress() != null ? device.getAddress() : "";
        name = device.getName() != null ? device.getName() : "";
      } catch (SecurityException ignored) {
      }
    }
    SharedPreferences prefs = context.getSharedPreferences("driveshield", Context.MODE_PRIVATE);
    if (!prefs.getBoolean("autoStart", true)) return;
    String wantId = prefs.getString("stereoId", "");
    String wantName = prefs.getString("stereoName", "");
    if ((wantId == null || wantId.isEmpty()) && (wantName == null || wantName.isEmpty())) return;
    if (!matches(wantId, wantName, id, name)) return;
    Intent open =
        new Intent(context, MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("carId", id)
            .putExtra("carName", name)
            .putExtra("autoStart", connected)
            .putExtra("autoStop", disconnected);
    try {
      context.startActivity(open);
    } catch (Exception ignored) {
    }
    if (connected) {
      try {
        TripTrackService.start(context);
      } catch (Exception ignored) {
      }
    } else {
      new android.os.Handler(context.getMainLooper())
          .postDelayed(() -> pingClassify(context), 20000);
    }
  }

  static void pingClassify(Context context) {
    try {
      if (Build.VERSION.SDK_INT >= 26) {
        NotificationChannel ch =
            new NotificationChannel(
                "driveshield_done", "Trip finished", NotificationManager.IMPORTANCE_HIGH);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.createNotificationChannel(ch);
      }
      Intent open =
          new Intent(context, MainActivity.class)
              .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
              .putExtra("autoStop", true);
      PendingIntent tap =
          PendingIntent.getActivity(
              context,
              7,
              open,
              PendingIntent.FLAG_UPDATE_CURRENT
                  | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
      NotificationCompat.Builder b =
          new NotificationCompat.Builder(context, "driveshield_done")
              .setContentTitle("DriveShield · trip ended")
              .setContentText("Car stereo off. Tap to mark business or personal.")
              .setSmallIcon(android.R.drawable.ic_dialog_info)
              .setContentIntent(tap)
              .setAutoCancel(true)
              .setPriority(NotificationCompat.PRIORITY_HIGH);
      NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
      if (nm != null) nm.notify(43, b.build());
    } catch (Exception ignored) {
    }
  }

  static boolean matches(String wantId, String wantName, String id, String name) {
    String a = safe(wantId);
    String b = safe(id);
    if (!a.isEmpty() && !b.isEmpty() && a.equals(b)) return true;
    String n = safe(wantName);
    String m = safe(name);
    if (n.isEmpty() || m.isEmpty()) return false;
    return n.equals(m) || n.contains(m) || m.contains(n);
  }

  private static String safe(String v) {
    return v == null ? "" : v.trim().toLowerCase();
  }
}
