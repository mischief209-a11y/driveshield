package app.driveshield.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class TripTrackService extends Service implements LocationListener {
  public static final String CHANNEL = "driveshield_trip";
  public static final int NOTE_ID = 42;
  public static final String ACTION_START = "app.driveshield.mobile.START_TRACK";
  public static final String ACTION_STOP = "app.driveshield.mobile.STOP_TRACK";
  public static final String ACTION_MILES = "app.driveshield.mobile.UPDATE_MILES";
  public static final String ACTION_CANCEL = "app.driveshield.mobile.CANCEL_TRACK";
  public static final String EXTRA_MILES = "miles";

  private static final ArrayList<double[]> trail = new ArrayList<>();
  private static double nativeMiles = 0;
  private static Location lastFix;

  private LocationManager locations;
  private PowerManager.WakeLock cpuLock;

  public static void start(Context ctx) {
    synchronized (trail) {
      trail.clear();
      nativeMiles = 0;
      lastFix = null;
    }
    Intent i = new Intent(ctx, TripTrackService.class).setAction(ACTION_START);
    if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
    else ctx.startService(i);
  }

  public static void stop(Context ctx) {
    ctx.stopService(new Intent(ctx, TripTrackService.class));
  }

  public static void miles(Context ctx, String text) {
    Intent i =
        new Intent(ctx, TripTrackService.class).setAction(ACTION_MILES).putExtra(EXTRA_MILES, text);
    if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
    else ctx.startService(i);
  }

  public static String trailJson() {
    JSONArray arr = new JSONArray();
    synchronized (trail) {
      for (double[] p : trail) {
        try {
          JSONObject row = new JSONObject();
          row.put("lat", p[0]);
          row.put("lng", p[1]);
          arr.put(row);
        } catch (Exception ignored) {
        }
      }
    }
    return arr.toString();
  }

  public static double trailMiles() {
    synchronized (trail) {
      return nativeMiles;
    }
  }

  @Override
  public void onCreate() {
    super.onCreate();
    ensureChannel();
    startForeground(NOTE_ID, buildNote("0.0 mi this trip"));
    try {
      PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
      if (pm != null) {
        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "driveshield:track");
        cpuLock.setReferenceCounted(false);
        cpuLock.acquire(6 * 60 * 60 * 1000L);
      }
    } catch (Exception ignored) {
    }
    try {
      locations = (LocationManager) getSystemService(LOCATION_SERVICE);
      if (locations != null) {
        locations.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 6f, this, Looper.getMainLooper());
        locations.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000, 20f, this, Looper.getMainLooper());
      }
    } catch (SecurityException ignored) {
    }
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    String action = intent != null ? intent.getAction() : ACTION_START;
    if (ACTION_STOP.equals(action) || ACTION_CANCEL.equals(action)) {
      if (ACTION_CANCEL.equals(action)) {
        try {
          getSharedPreferences("driveshield", MODE_PRIVATE)
              .edit()
              .putBoolean("cancelTrip", true)
              .apply();
        } catch (Exception ignored) {
        }
        MainActivity.requestCancelTrip();
      }
      stopForeground(true);
      stopSelf();
      return START_NOT_STICKY;
    }
    String text = intent != null ? intent.getStringExtra(EXTRA_MILES) : null;
    if (text == null || text.isEmpty()) {
      text = String.format(Locale.US, "%.1f mi this trip", trailMiles());
    }
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (nm != null) nm.notify(NOTE_ID, buildNote(text));
    startForeground(NOTE_ID, buildNote(text));
    return START_STICKY;
  }

  @Override
  public void onLocationChanged(Location location) {
    if (location == null) return;
    if (location.hasAccuracy() && location.getAccuracy() > 45) return;
    synchronized (trail) {
      if (lastFix != null) {
        float meters = lastFix.distanceTo(location);
        if (meters < 12) return;
        double hours = Math.max(1, location.getTime() - lastFix.getTime()) / 3600000.0;
        double mph = (meters / 1609.344) / Math.max(hours, 1.0 / 3600.0);
        if (mph > 110) {
          lastFix = location;
          return;
        }
        if (meters >= 12) nativeMiles += meters / 1609.344;
      }
      lastFix = location;
      trail.add(new double[] {location.getLatitude(), location.getLongitude()});
      if (trail.size() > 1200) {
        ArrayList<double[]> slim = new ArrayList<>();
        for (int i = 0; i < trail.size(); i += 2) slim.add(trail.get(i));
        trail.clear();
        trail.addAll(slim);
      }
    }
    String line = String.format(Locale.US, "%.1f mi this trip", trailMiles());
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (nm != null) nm.notify(NOTE_ID, buildNote(line));
    MainActivity.pushGps(location.getLatitude(), location.getLongitude(), location.getAccuracy());
  }

  @Override
  public void onDestroy() {
    if (cpuLock != null && cpuLock.isHeld()) {
      try {
        cpuLock.release();
      } catch (Exception ignored) {
      }
    }
    if (locations != null) {
      try {
        locations.removeUpdates(this);
      } catch (Exception ignored) {
      }
    }
    super.onDestroy();
  }

  @Nullable
  @Override
  public IBinder onBind(Intent intent) {
    return null;
  }

  private void ensureChannel() {
    if (Build.VERSION.SDK_INT < 26) return;
    NotificationChannel ch =
        new NotificationChannel(CHANNEL, "Trip tracking", NotificationManager.IMPORTANCE_LOW);
    ch.setDescription("Shows while DriveShield is recording a drive");
    ch.setShowBadge(false);
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (nm != null) nm.createNotificationChannel(ch);
  }

  private Notification buildNote(String miles) {
    int flags =
        PendingIntent.FLAG_UPDATE_CURRENT
            | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent tap = PendingIntent.getActivity(this, 0, open, flags);
    PendingIntent cancel =
        PendingIntent.getService(
            this,
            9,
            new Intent(this, TripTrackService.class).setAction(ACTION_CANCEL),
            flags);
    String line = miles != null && !miles.isEmpty() ? miles : "Recording trip";
    return new NotificationCompat.Builder(this, CHANNEL)
        .setContentTitle("DriveShield · recording")
        .setContentText(line)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setContentIntent(tap)
        .addAction(0, "Cancel trip", cancel)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
        .build();
  }
}
